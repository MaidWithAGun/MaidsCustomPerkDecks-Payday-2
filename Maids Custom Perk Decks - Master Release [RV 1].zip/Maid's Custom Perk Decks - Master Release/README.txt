Hi. I recommend you read this before you do anything with this mod.

A few basics |

These modded perk decks will not be seen properly by people that do not have the mod installed.

You should probably ask your session host [if you join a session that is not yours] if it's okay to use these, since they contain SEVERE 
in-game modifications that some hosts deem cheating. [You do not need to but it's still advised]

This mod only works with the SuperBLT Mod Manager, make absolutely SURE you have this mod assigned to that mod manager.

You generally should not touch any of these files unless you have expertise in coding and know what your doing.

If you want a new perk deck added, you should probably ask me, as i could give you a seperate release containing your perk, it will save you
time and possible frustration from you attempting to add your own without proper knowledge.



